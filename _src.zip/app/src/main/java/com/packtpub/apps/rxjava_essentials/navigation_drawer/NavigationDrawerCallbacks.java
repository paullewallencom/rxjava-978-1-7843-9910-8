package com.packtpub.apps.rxjava_essentials.navigation_drawer;

public interface NavigationDrawerCallbacks {

    void onNavigationDrawerItemSelected(int position);
}
